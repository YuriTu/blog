var mock = {
    user: require('./user/user'),
    left: require('./content/left'),
    panel:require('./content/panel'),
    feed:require('./content/feed')
}

export default mock;
