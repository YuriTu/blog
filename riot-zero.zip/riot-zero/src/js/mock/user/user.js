/**
 * @file Describe the file
 * @author 涂强（tuqiang01@baidu.com）
 */
import Mock from 'mockjs'
module.exports = Mock.mock(/f\/user\/json_userinfo\.json/,{
    'user_name_show':Mock.Random.first(),
    'user_icon':Mock.Random.image('80x80'),
    'user_dou_count':Math.ceil(Math.random() * 100)

})