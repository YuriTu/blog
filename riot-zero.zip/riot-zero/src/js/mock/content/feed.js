/**
 * @file Describe the file
 * @author 涂强（tuqiang01@baidu.com）
 */

import Mock from 'mockjs';

module.exports = Mock.mock(/f\/feed\/getfeeddata\.json/,{
    'game|2':[{
        'name':Mock.Random.word(3,5),
        'icon':Mock.Random.image('180x140'),
        'list|5':[{
            text:Mock.Random.word(3,5),
            href:Mock.mock('@url'),
        }]
    }],
    'list':{
        nav:[]
    }
})