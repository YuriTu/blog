/**
 * @file Describe the file
 * @author 涂强（tuqiang01@baidu.com）
 */

import Mock from 'mockjs'

module.exports = Mock.mock(/f\/user\/getrecommend\.json/,{
    'header':'朵朵奇吧',
    'child':'膜拜推荐界大佬',
    'list|2':[{
        'name':Mock.Random.word(1,5),
        'intro':Mock.mock('@string(5)'),
        'user':Mock.Random.integer(1,5000),
        'command':Mock.Random.integer(1,500000),
        'icon':Mock.Random.image('95x95')
    }],
    'recommend|4':[{
        'name':Mock.Random.word(1,5),
        'user':Mock.Random.integer(1,5000),
        'icon':Mock.Random.image('65x65'),
        'tags':Mock.Random.word(1,3)
    }]
})