/**
 * @file Describe the file
 * @author 涂强（tuqiang01@baidu.com）
 */

import Mock from 'mockjs'
module.exports = Mock.mock(/f\/user\/getlickedba\.json/,{
    'likedlist|1-10':[{
        'name|1':Mock.Random.word(1,5),
        rank:Mock.Random.integer(1,3),
        href:Mock.Random.url()
    }]
})