import axios from 'axios' ;

var http = http || {};
http.url = {
    menu: './datas/menu.json',
}

http.get = function(opts){
    axios({
      method: 'get',
      url: opts.url,
      data: JSON.stringify(opts.params)
    })
    .then(function(res){
        opts.callback(res);
    })
    .catch(function(err){
        console.log(err);
    })
};
http.post = function(opts){
    axios({
      method: 'post',
      url: opts.url,
      data: opts.params
    })
    .then(function(res){
        opts.callback(res);
    })
    .catch(function(err){
        console.log(err);
    })
};
export default http;
