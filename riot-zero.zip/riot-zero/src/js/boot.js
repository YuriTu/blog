/**
 * @file 练习项目
 * @author tuqiang (tuqiang01@baiud.com)
 */
import './router';
import './tags.min.js';
import Service from './service/service';

import config from '../config/basic';

const S = new Service();
window.S = S;

let riot = window.riot;
riot.mount('nav-list', {config: config.navList});
riot.mount('search', {config: config.search});
riot.mount('banner',{config:config.banner})
riot.mount('content',{config:config.content})

