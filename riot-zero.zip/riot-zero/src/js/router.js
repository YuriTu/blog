
import riotRouter from 'riot-seed-router';
riotRouter({
    '#content': [
        { route: '/route1', tag: 'route1'},
        { route: '/route2', tag: 'route2'}
        ]
});
