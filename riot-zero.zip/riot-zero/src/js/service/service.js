import http from '../http'
const $http = (url,data) => {
    return new Promise((resolve,reject) => {

        http.get({
            url: url,
            params: data,
            callback: (rs) => {
                resolve(rs);
            }
        });
    });
}


class Service {
    getTopiList(data) {
        return $http('/hottopic/browse/topicList', data);
    }
    getSearchddl(data) {
        return $http('/suggestion', data);
    }
    getUserInfo(data) {
        return $http('/f/user/json_userinfo.json', data);
    }
    getLikedList(data) {
        return $http('f/user/getlickedba.json',data)
    }
    getRecommend(data) {
        return $http('f/user/getrecommend.json',data)
    }
    getFeedData(data) {
        return $http('f/feed/getfeeddata.json',data)
    }
    getFeedList(data,dataUrl) {
        return $http(`f/index/feedlist${dataUrl}`,data)
    }
}

module.exports = Service
