import 'babel-polyfill';
import $ from 'jquery';
import './mock';
import store from './store';
import http from './http';
import flux from 'riot-seed-flux';
// import Data from './data';
