/**
 * @file Describe the file
 * @author 涂强（tuqiang01@baidu.com）
 */

import flux from 'riot-seed-flux'
import http from '../../http'

module.exports = flux.createStore({
    get:function () {
        let self = this;
        S.getUserInfo({}).then(rs => {
            self.user_info = rs.data.user_name_show;
            self.user_dou_count = rs.data.user_dou_count;
            self.user_icon = rs.data.user_icon;
            self.trigger('complete')
        })
    }

})