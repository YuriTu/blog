import flux from 'riot-seed-flux'
import http from '../../http'

module.exports = flux.createStore({
    get: function(cb){
        var self =this;
        http.get({
            url:http.url.menu,
            callback:function(res){
                self.data = res.data;
                self.trigger('complete');
            }
        })
    }
})
