/**
 * @file Describe the file
 * @author 涂强（tuqiang01@baidu.com）
 */

import flux from 'riot-seed-flux'

module.exports = flux.createStore({
    set:function(show){
        this.show = show;
        this.trigger('complete');
    }
})