/**
 * @file Describe the file
 * @author 涂强（tuqiang01@baidu.com）
 */
import flux from 'riot-seed-flux'

module.exports = flux.createStore({
    get:function () {
        let self = this;
        S.getLikedList({}).then(rs => {
            self.likedlist = rs.data.likedlist;
            self.trigger('complete');
        })
    }
})