/**
 * @file Describe the file
 * @author 涂强（tuqiang01@baidu.com）
 */

import flux from 'riot-seed-flux';

module.exports = flux.createStore({
    get: function () {
        let self = this;
        S.getFeedData({}).then(rs => {
            self.feed = rs.data;
            self.trigger('complete');
        })
    }
})