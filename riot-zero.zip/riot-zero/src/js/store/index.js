import flux from 'riot-seed-flux';
var store = {
    example: require('./example'),
    search:require('./search/search'),
    user:require('./user/user'),
    content:require('./content/left'),
    panel:require('./content/panel'),
    feed:require('./content/feed')
}

export default store;
