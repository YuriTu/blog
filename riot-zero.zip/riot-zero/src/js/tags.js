import 'babel-polyfill';
import $ from 'jquery';
import './mock';
import store from './store';
import http from './http';
import flux from 'riot-seed-flux';
// import Data from './data';

riot.tag2('route1', '<h6>{title}</h6>', '', '', function(opts) {
        var self = this;
        self.on('mount',function(){
            self.title ='这是route1';
            self.update();
        })

});

riot.tag2('route2', '<h6>{route}</h6>', '', '', function(opts) {
        var self = this;
        self.route ='这是route2';
        self.update();
});

riot.tag2('test', '<ul style="overflow:hidden;"> <li each="{item,i in list}" style="float:left;"> <span>{item.name}</span> <img riot-src="{item.logo}" alt="" style="width:100px;height:100px;"> </li> </ul> <div> <a href="#route1">route1</a> <a href="#route2">route2</a> </div>', '', '', function(opts) {
    var self = this;

    self.on('mount',function(){
        flux.bind.call(self,{
            name:'menu',
            store:store.example,
            success:function(){

                self.list = self.menu.list;
                self.update();
            }
        })
    })

});
