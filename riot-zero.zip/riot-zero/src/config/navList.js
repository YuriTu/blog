/**
 * @file navList config
 * @author 涂强（tuqiang01@baidu.com）
 */

module.exports = [
    {text: '网页', href: '#'},
    {text: '新闻', href: '#'},
    {text: '贴吧', href: '#'},
    {text: '知道', href: '#'},
    {text: '音乐', href: '#'},
    {text: '图片', href: '#'},
    {text: '视频', href: '#'},
    {text: '地图', href: '#'},
    {text: '文库', href: '#'},
    // 8
    {text: '百度首页', href: '#', className: 'ddl-index left-border'},
    {text: 'Hao123', href: '#', className:'ddl-index'},
    {
        text: 'username',
        href: '#',
        className:'ddl-index',
        dropList: [
            {text: '我的贴吧', href: '#'},
            {text: '我的商城', href: '#'},
            {text: '我的收藏', href: '#'},
            {text: '我的网盘', href: '#'},
            {text: '我的游戏', href: '#'},
            {text: '我的蓝钻', href: '#'}
        ]
    },
    {
        text: '消息',
        className:"message ddl-index",
        href: '#',
        dropList: [
            {text: '查看私信', href: '#'},
            {text: '查看回复', href: '#'},
            {text: '查看@到我', href: '#'},
            {text: '查看好友申请', href: '#'},
            {text: '查看新粉丝', href: '#'},
            {text: '我的收藏', href: '#'}
        ]
    },
    {
        text: '会员',
        className:"member ddl-index",
        href: '#',
        icon: 'i-member',
        dropList: [
            {text: 'T豆钱包', href: '#', icon: 'i-dropdown-dou'},
            {text: 'T豆商城', href: '#', icon: 'i-dropdown-tbmall'},
            {text: '会员官网', href: '#', icon: 'i-dropdown-member',className:"member-red"}
        ]
    },
    {
        text: '更多',
        className:"more",
        className:'ddl-index',
        href: '#',
        dropList: [
            {text: '手机APP', href: '#'},
            {text: '应用中心', href: '#'},
            {text: '账号设置', href: '#'},
            {text: '贴吧设置', href: '#'},
            {text: '服务中心', href: '#'},
            {text: '问题反馈', href: '#'},
            {text: '退出', href: '#'}
        ]
    }
];
