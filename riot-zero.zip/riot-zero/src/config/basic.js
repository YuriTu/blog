/**
 * @file 基础配置文件
 * @author 涂强（tuqiang01@baidu.com）
 */
import navList from './navList';
import search from './search';
import banner from './banner';
import content from './content'
module.exports = {
    navList,
    search,
    banner,
    content
};
