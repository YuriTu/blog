/**
 * @file Describe the file
 * @author 涂强（tuqiang01@baidu.com）
 */

module.exports = {
    img:"../imgs/search_logo_big.png",
    enter:{
        text:"进入贴吧",
        className:"enter"
    },
    sall:{
        text:"全吧搜索",
        className:"sall"
    },
    adv:{
        text:"高级搜索"
    }
}
