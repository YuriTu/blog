const webpack = require('webpack');
module.exports = {
    entry: './src/js/boot.js',
    output: {
        filename: 'bundle.min.js'
    },
    plugins: [
        new webpack.ProvidePlugin({
            riot: 'riot',
            "window.riot":'riot',
            "$":'jquery',
        })
    ],
    module: {
        loaders: [
            {test: /\.css$/, loader: 'style!css'},
            {
                test: /\.js|\.tag$/,
                loader: 'babel',
                exclude: /node_modules/,
                query: {
                    cacheDirectory: true,
                    presets: ['es2015'],
                    compact: false
                }
            },

        ]
    }
}
