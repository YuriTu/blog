# riot-zero 新手demo项目

## 目的
1、能够快速熟悉hi团队的主力ui框架riot的使用
2、理解前端自动化构建，了解gulp和webpack的基本用法
3、了解前后端分离开发模式和数据mock
4、了解riot-seed-flux管理数据。
## 相关资源
- [riot官网](http://riotjs.com/)
- [riot github](https://github.com/riot/riot)
- [riot-seed(自研)](https://github.com/be-fe/riot-seed)
- [gulp-bird](https://github.com/be-fe/gulp-bird)
- [百度代码规范大全](http://origin.eux.baidu.com/pages/home.html#/index?note=692&_k=kfh260)

## 安装项目过程需要注意的地方

1、window系统在下载依赖包的时候可能会报错(系统差异导致)，可以先忽略报错，继续一个个下载。npm install 包1 包2 包3...

## 启动项目

1、开发环境

```sh
npm run dev
```
2、生产环境

```sh
npm run build
```
## 要求
1、创建一个分支，分支名==你的百度邮箱前缀

2、用前后端分离模式实现以下需求中的一种

    - 拉取百度贴吧首页接口，渲染界面
    - Hi企业平台应用中心界面渲染
