#!/usr/bin/env bash

mv ./src/css/common/sprite.png ./src/sprite.png