const gulp = require('gulp');
const riot = require('gulp-riot');
const concat  = require('gulp-concat');
const webpack = require('webpack-stream');
const less = require('gulp-less');
const autoprefix = require('gulp-autoprefixer');
const postcss = require('gulp-postcss');
const del = require('del');
const nodemon = require('gulp-nodemon');
const spritesmith = require('gulp.spritesmith');
const minifyCss = require('gulp-minify-css');
const minifyHtml = require('gulp-minify-html');
const stripDebug = require('gulp-strip-debug');
const uglify = require('gulp-uglify');
const rev = require('gulp-rev');
const usemin = require('gulp-usemin');

/*
 * 处理less to css的task, 加入了autoprefix处理兼容性
 */
gulp.task('less',function(){
    gulp.src(['src/css/global.less', 'src/css/**/*.less'])
    .pipe(less())
    .pipe(concat('bundle.min.css'))
    .pipe(autoprefix())
    .pipe(gulp.dest('src'))
});

/*
 * 自动生成雪碧图, 手动执行 gulp sprite
 */
gulp.task('sprite', function () {
    gulp.src('src/imgs/icons/*.png').pipe(spritesmith({
        imgName: 'sprite.png',
        cssName: 'sprite.less'
    }))
    .pipe(gulp.dest('src/css/common'));
});

/*
 * 用webpack进行依赖管理
 */
gulp.task('webpack', ['riot'], function () {
    gulp.src('src/js/boot.js')
    .pipe(webpack(require('./webpack.config.js')))
    .pipe(gulp.dest('src'))
});

/*
 * 将riot tag编译成js并进行合并
 */
gulp.task('riot',function(){
    return gulp.src(['src/js/tags-dep.js', 'src/tag/**'])
    .pipe(riot())
    .pipe(concat('tags.min.js'))
    .pipe(gulp.dest('src/js'))
});

/*
 * 启动dev server
 */
gulp.task('dev-serve',function(){
    nodemon({
        script: 'server.js',
        ext: 'js',
        watch: ['server.js'],
        env: { 'PORT': process.argv[process.argv.length-1] }
    });
})

/*
 * 进行watch，监听文件变化自动构建
 */
 gulp.task('dev',['riot','webpack','less','dev-serve'],function(){
     gulp.watch(['src/tag/**/*.tag','src/js/tags-dep.js','src/tag/components/*.tag'], ['riot','webpack']);
     gulp.watch(['src/js/**/*.js', '!src/js/tags.js','!src/js/tags-dep.js'], ['webpack']);
     gulp.watch('src/css/**/*.less', ['less']);
 });

/*
 * 删除dist目录
 */
 gulp.task('clean',function(){
     return del(['dist/**']);
 })
/*
 * 生产环境
 */
 gulp.task('dist',['clean'],function(){
     gulp.src('./src/index.html')
     .pipe(usemin({
         css: [ minifyCss(), rev() ],
         html: [ minifyHtml({ empty: true }) ],
         js: [ uglify(), rev(), stripDebug() ],
         inlinejs: [ uglify(), stripDebug() ],
         inlinecss: [ minifyCss, 'concat' ]
     }))
     .pipe(gulp.dest('./dist'))
 })
gulp.task('default',['dev']);
