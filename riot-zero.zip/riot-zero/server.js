const bird = require('gulp-bird');

var server = {
    "8007": {
        //静态文件根目录
        "basePath": "./src",
    }
};
//转发规则——静态服务器没有响应的或者忽略的请求将根据一下规则转发
var transpondRules = {
    "8007": {
        //目标服务器的ip和端口，域名也可，但注意不要被host了
       targetServer: {
            "port": "80",
            "host": "tieba.baidu.com",
            "replaceHeaders": true, //当为true时，如果cookie or header中有相同key，则替换
            "headers": {
                "cookie": "BDUSS=kM4am82QXpyazRVdEIzMUxKWGJKSERCeXR-N0p-ck5ydVlZRU55MnFrRmROVzlaSUFBQUFBJCQAAAAAAAAAAAEAAACLfV6bAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAF2oR1ldqEdZW",
                Host: "tieba.baidu.com",
                Referer: "http://tieba.baidu.com/"
            }
        },
    },
    "ajaxOnly": false
};

bird.start(server, transpondRules);
